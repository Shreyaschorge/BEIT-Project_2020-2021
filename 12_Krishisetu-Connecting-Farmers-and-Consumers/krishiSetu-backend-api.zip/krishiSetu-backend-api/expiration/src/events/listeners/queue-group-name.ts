export const queueGroupName = 'expiration-service';
