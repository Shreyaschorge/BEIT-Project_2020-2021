import jwt from 'jsonwebtoken';

const getCookie = () => {
  const currentUser = JSON.parse(window.localStorage.getItem('currentUser'));

  console.log("cU",currentUser);

  const JWT_KEY = `'0146723f58418b68903dab56fac0636d3b740382ebe7eb1fd32955d9f8882152fb5977ddfcbe3e37f942cc146ae3cf5e460f1139369555fe7b012fca9f1ef12e'`;

  const token = jwt.sign(currentUser, JWT_KEY);

  const session = {jwt : token};

  const sessionJSON =JSON.stringify(session);

  const base64 = Buffer.from(sessionJSON).toString('base64');

  return `express:sess=${base64}`;
}

export default getCookie;