// const dummyData = [
//   {
//       title: 'Product1',
//       imageSrc: 'https://images2.minutemediacdn.com/image/upload/c_crop,h_1126,w_2000,x_0,y_181/f_auto,q_auto,w_1100/v1554932288/shape/mentalfloss/12531-istock-637790866.jpg',
//       price: '270'
//   },
//   {
//       title: 'Product2',
//       imageSrc: 'https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/gettyimages-1036880806.jpg?crop=0.6666666666666666xw:1xh;center,top&resize=640:*',
//       price: '258'
//   },
//   {
//       title: 'Product3',
//       imageSrc: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8Mjl8fHxlbnwwfHx8fA%3D%3D&w=1000&q=80',
//       price: '782'
//   },
//   {
//       title: 'Product4',
//       imageSrc: 'https://images.immediate.co.uk/production/volatile/sites/30/2020/08/chorizo-mozarella-gnocchi-bake-cropped-9ab73a3.jpg?quality=90&resize=700%2C636',
//       price: '822'
//   },
//   {
//       title: 'Product5',
//       imageSrc: 'https://c.ndtvimg.com/2020-04/dih4ifhg_pasta_625x300_22_April_20.jpg',
//       price: '720'
//   },
// ];

// async function fetchProducts () {
//   return Promise.resolve(dummyData);
// } 

// export default fetchProducts;