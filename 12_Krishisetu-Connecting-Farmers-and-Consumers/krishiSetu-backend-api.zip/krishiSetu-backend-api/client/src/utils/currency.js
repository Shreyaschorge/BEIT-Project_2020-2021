const DENOMINATION = 'Rs';

export default DENOMINATION;