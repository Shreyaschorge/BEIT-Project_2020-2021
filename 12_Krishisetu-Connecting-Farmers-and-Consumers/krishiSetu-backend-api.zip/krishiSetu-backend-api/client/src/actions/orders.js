import axios from 'axios';
import { ALL_ORDERS, CURRENT_ORDER, SET_ERRORS} from 'actions/constants';
import history from "../history";
import {toast} from 'react-toastify';

export const newOrder = (productId) => async (dispatch) => {

  console.log(productId);

  const prod = {
    productId: productId
  }

  try {
    await axios.post('http://orders-srv:3000/api/orders/', prod, {
      headers : {
        'Content-Type': 'application/json'
      }
    });

    toast.success('Order Created', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

    history.push('my-orders');

  } catch (err) {
    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })
  }

}

export const fetchAllOrders = () => async (dispatch) => {
  try {

    const {data} = await axios.get('http://orders-srv:3000/api/orders/', {
      headers: {
        'Content-Type': 'application/json'
      }
    })

    dispatch({
      type: ALL_ORDERS,
      payload: data
    })
    
  } catch (err) {
    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })
  }
}

export const currentOrder = (order) => async (dispatch) => {
    dispatch({
      type: CURRENT_ORDER,
      payload: order
    })

    history.push('/payment')
}