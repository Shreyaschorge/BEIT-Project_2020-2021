import axios from 'axios';

import {CURRENT_USER, SIGNOUT, SET_ERRORS } from 'actions/constants';
import history from '../history';
import {toast} from 'react-toastify';

export const getCurrentUser =  () => async (dispatch)=> {
  
  const {data} = await axios.get('http://auth-srv:3000/api/users/currentuser', {headers: {
    'Content-Type': 'application/json'
    }});

    console.log("data", data)

  dispatch({
    type: CURRENT_USER,
    payload: data.currentUser
  })
}

export const signup = (user) => async (dispatch) => {

  try {
    const {data} = await axios.post('http://auth-srv:3000/api/users/signup',  user, {headers: {
    'Content-Type': 'application/json'
    }});

    dispatch({
      type: CURRENT_USER,
      payload: data
    });

    toast.success('Account Created Succesfully', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

    history.push('/home');

  } catch (err) {

    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })

  }
}

export const signin = (user) => async (dispatch) => {

  try {
    const {data} = await axios.post('http://auth-srv:3000/api/users/signin', user, {headers: {
    'Content-Type': 'application/json'
    }});

    dispatch({
      type: CURRENT_USER,
      payload: data
    });

    history.push('/home');

    toast.success('Succesfully Signed In', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

  } catch (err) {
    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })
  }

  
}

export const signout = () => async (dispatch) => {
  await axios.post('http://auth-srv:3000/api/users/signout');

  dispatch({
    type: SIGNOUT
  })

  toast.success('Succesfully Signed Out', {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  });

  history.push('/home');

}