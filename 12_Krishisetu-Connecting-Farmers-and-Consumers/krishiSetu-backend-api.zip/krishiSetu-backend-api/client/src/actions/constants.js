//  Auth
export const CURRENT_USER = 'CURRENT_USER';
export const SIGNOUT = 'SIGNOUT';

//  Error Handling
export const SET_ERRORS = 'SET_ERRORS';

//  Loading
export const LOADING = "LOADING";

//  Products
export const ALL_PRODUCTS = "ALL_PRODUCTS";
export const USERS_PRODUCTS = "USERS_PRODUCTS";
export const CURRENT_PRODUCT = "CURRENT_PRODUCT";

//  Orders
export const ALL_ORDERS = "ALL_ORDERS";
export const CURRENT_ORDER = "CURRENT_ORDER"