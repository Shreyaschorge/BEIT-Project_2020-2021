import axios from 'axios';
import getCookie from 'utils/getCookie';
import history from '../history';

import {toast} from 'react-toastify';

import { ALL_PRODUCTS, USERS_PRODUCTS, SET_ERRORS, CURRENT_PRODUCT } from 'actions/constants';

export const fetchAllProducts = () => async (dispatch) => {
  try {
    const {data} = await axios.get('http://products-srv:3000/api/products', {
      headers: {
        'Content-Type': 'application/json',
        // 'Set-Cookie' : getCookie()
      }
    });

    dispatch({
      type: ALL_PRODUCTS,
      payload: data
    })

  } catch (err) {
    
    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })

  }
}

 export const fetchUserProducts = () => async (dispatch) => {
   try {
     const {data} = await axios.get('http://products-srv:3000/api/products/userProducts', {
       headers: {
         'Content-Type': 'application/json'
       }
     });

     dispatch({
       type: USERS_PRODUCTS,
       payload: data
     })

   } catch (err) {
    
     dispatch({
       type: SET_ERRORS,
       payload: err.response.data.errors
     })

   }
 }

export const addProduct = (_data) => async (dispatch) => {
  try {

    const image = _data.image[0];

    const uploadConfig = await axios.get('http://products-srv:3000/api/products/upload/');
    
    await axios.put(uploadConfig.data.url, image, {
      headers: {
        'Content-Type': image.type,
      }
    });

    const product = {
      title : _data.title,
      price : _data.price,
      description : _data.description,
      imageURL : uploadConfig.data.key
    }

    await axios.post('http://products-srv:3000/api/products', product, {
      headers: {
        'Content-Type': 'application/json',
      }
    });

    toast.success('Product Created', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

    history.push('sell-products');

  } catch (err) {
    
    dispatch({
      type: SET_ERRORS,
      payload: err.response.data.errors
    })

  }
}

export const setCurrentProduct = (product) => (dispatch) => {
  dispatch({
    type: CURRENT_PRODUCT,
    payload: product
  })
}