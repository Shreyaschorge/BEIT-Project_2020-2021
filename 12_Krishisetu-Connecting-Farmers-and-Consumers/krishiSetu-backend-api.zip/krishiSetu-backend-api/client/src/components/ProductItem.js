import React from 'react';
import {useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';

import {setCurrentProduct} from 'actions/products';

import DENOMINATION from 'utils/currency';


const ProductItem = ({title, imageURL, price, description, productId, userId}) => {

  const dispatch = useDispatch();

  return (<div className="
  w-100
  md:w-1/2
  lg:w-1/4
  p1 sm:p-2
" onClick={() => dispatch(setCurrentProduct({title, imageURL, price, description, productId ,userId}))} >
  <Link to='/product'>
    <div aria-label={title}>
      <div className="h-72 flex justify-center items-center bg-light hover:bg-light-200">
        <div className="flex flex-column justify-center items-center">
          <img alt={title} src={`https://krishisetu.s3.ap-south-1.amazonaws.com/${imageURL}`} className="max-h-full" width='50%' />
          {/* <img alt={title} src={`${imageURL}`} className="max-h-full" width='50%' /> */}
        </div>
      </div>
    </div>
  </Link>
  <div>
    <h5 className="m-4 text-center text-l font-semibold mb-1">{title}</h5>
    <h5 className="text-center text-gray-700 mb-4">{`${DENOMINATION} ${' '}${price}`}</h5>
  </div>
</div>)
}

export default ProductItem;