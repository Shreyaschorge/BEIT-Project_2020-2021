import React from 'react'

const Footer = () => {
  return (
    <div>
    
    <footer className="flex justify-center">
        <div className="
        sm:flex-row sm:items-center
        flex-col
        flex w-fw px-12 py-8
        desktop:px-0
        border-solid
        border-t border-gray-300">
          <span className="block text-gray-700 text-xs">Developed by</span>
          
          <div className="
            sm:justify-end sm:m-0
            flex flex-1 mt-4
          ">
            <h4 className="text-xxs font-semibold tracking-tight m-0 leading-tight">Shreyas Chorge, Vedangi Naigaonkar, Abhijit Ambre</h4>
          </div>
        </div>
      </footer>
    </div>

  )
}

export default Footer
