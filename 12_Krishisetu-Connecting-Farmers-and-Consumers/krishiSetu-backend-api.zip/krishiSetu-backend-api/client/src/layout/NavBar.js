import React from 'react';
import { useSelector } from "react-redux";
import {Link} from 'react-router-dom';

const NavBar = () => {
  const {currentUser} = useSelector((state) => state.auth);

  console.log(currentUser)

  const links = [
    !currentUser && {label: 'Signup', href: '/signup'},
    !currentUser && {label: 'Signin', href: '/signin'},
    currentUser && {label: 'Sell Products', href: '/sell-products'},
    currentUser && {label: 'My Order', href: '/my-orders'},
    currentUser && {label: 'Signout', href: '/signout'},
  ]
  .filter((links) => links)
  .map(({label, href}) => {
    return  (
        <div key={href} className="mb-4 sm:mr-16 max-w-48 sm:max-w-non">
          <Link to={href}>
            <label aria-label="Home" className='cursor-pointer' >
            <h1 className="sm:mr-8 sm:mb-0 mb-4 text-left text-smaller mr-4">
              {label}
            </h1>
            </label>
          </Link>
        </div> 
        )});

  return (
    <>
    <nav>
        <div className="flex justify-center">
          <div className="
            mobile:px-12 sm:flex-row sm:pt-12 sm:pb-6 desktop:px-0
            px-4 pt-8 flex flex-col w-fw justify-between
          ">
            <div className="mb-4 sm:mr-16 max-w-48 sm:max-w-none">
              <Link to='/home'>
                <label aria-label="Home" className='cursor-pointer'>
                  {/* <img src="/logo.png" alt="logo" width="90" height="28" /> */}
                  <h1>KrishiSetu</h1>
                </label>
              </Link>
            </div>
            <div className="flex flex-wrap mt-1">
              {links}
            </div>
          </div>
        </div>
      </nav>
    </>
  )
}

export default NavBar
