import React, {useState} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import Button from 'components/Button';
import DENOMINATION from 'utils/currency';

import {newOrder} from 'actions/orders';

const Product = () => {

  const {currentProduct} = useSelector((state) => state.products);
  const {currentUser} = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  return (
    <>
    { !currentProduct ? (<></>) : (
      <div>
        <div className="
            sm:py-12
            px-2
            md:flex-row
            py-4 w-full flex flex-1 flex-col my-0 mx-auto
          ">
            <div className="w-full md:w-1/2 h-120 flex flex-1 bg-light hover:bg-light-200">
              <div className="py-16 p10 flex flex-1 justify-center items-center">
                <img src={`https://krishisetu.s3.ap-south-1.amazonaws.com/${currentProduct.imageURL}`} className="max-h-full" />
              </div>
            </div>
            <div className="pt-2 px-0 md:px-10 pb-8 w-full md:w-1/2">
              <h1 className="
              sm:mt-0 mt-2 text-5xl font-light leading-large
              ">{currentProduct.title}</h1>
              <h2 className="text-2xl tracking-wide sm:py-8 py-6">{DENOMINATION}{currentProduct.price}</h2>
              <h4 className="text-gray-600 leading-7">
                {currentProduct.description}
              </h4>
              <div className="my-6">
                {/* {QuantityPicker()} */}
              </div>

              {
                currentUser.id !== currentProduct.userId ? (<Button
                full
                title="Place an Order"
                onClick={() => dispatch(newOrder(currentProduct.productId))}
              />) : <></>
              }

              
            </div>
          </div>  
      </div>
    )}
  </>
  )
}

export default Product;