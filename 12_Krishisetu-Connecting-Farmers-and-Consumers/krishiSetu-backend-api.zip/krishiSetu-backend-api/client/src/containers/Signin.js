import React, {useEffect} from 'react';
import {useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';
import { useForm } from "react-hook-form";

import {signin} from 'actions/auth';

const Signin = () => {

  const { register, handleSubmit, formState: { errors }, reset, formState } = useForm();
  const dispatch = useDispatch();

  const onSubmit = async (data) => {
    dispatch(signin(data))
  }

  useEffect(() => {
    if (formState.isSubmitSuccessful) {
      reset({ email: '', password: ''});
    }
  }, [formState, reset]);

  return (   

    <div className="flex flex-col">
        <div className="max-w-fw flex flex-col">
        <div className="flex flex-1 justify-center">
          <div className="w-full max-w-144">
            <form className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4" onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-4">
              <h1 className="text-4xl font-light my-2">Sign In</h1>

              <hr className='my-5'/>
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="email">
                  Email
                </label>
                <input
                  {...register("email", {required: "This field is required"})}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"  type="text" placeholder="Email" />
                {errors.email && <p className="text-red-300">{errors.email.message}</p>}
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="password">
                  Password
                </label>
                <input
                  {...register("password", {required : "This field is  required", minLength: {value: 4, message: "Password should be greater than 4 characters"}})}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline" type='password' placeholder="******************" />
                {errors.password && <p className="text-red-300">{errors.password.message}</p>}
              </div>
              <div className="flex items-center justify-between">
                <button className="bg-primary hover:bg-black text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                  Sign In
                </button>
                <Link to="/signup">
                  <label className='cursor-pointer text-gray-600 hover:text-blue-300'>Don't have an account..?</label>
                </Link>
              </div>
            </form>
          </div>
        </div>
        </div>
      </div>

   )
}

export default Signin
