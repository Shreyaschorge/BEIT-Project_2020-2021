import React, {useState, useEffect} from 'react'
import {useSelector} from 'react-redux';
import axios from 'axios';
import {toast} from 'react-toastify';

import history from '../history';

import DENOMINATION from 'utils/currency';
import Button from 'components/Button';


const Payment = () => {

  const {currentOrder} = useSelector((state) => state.orders)

  const doRequest = async () => {

    const charge = {
      orderId: currentOrder.id,
      token: 'tok_visa',
      price: currentOrder.product.price
    }

    try {
      await axios.post('http://localhost:5000/api/payments/', charge, {
      headers: {
        'Content-Type': 'application/json'
      }
    })
    } catch (err) {
      console.log(err.response.data.errors)
    }

    

    toast.success('Payment Completed', {
      position: "top-right",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    });

    history.push('home')

  }

  return (
    <div>

      <div>
        <div className="
            sm:py-12
            px-2
            md:flex-row
            py-4 w-full flex flex-1 flex-col my-0 mx-auto
          ">
            <div className="w-full md:w-1/2 h-120 flex flex-1 bg-light hover:bg-light-200">
              <div className="py-16 p10 flex flex-1 justify-center items-center">
                <img src={`https://krishisetu.s3.ap-south-1.amazonaws.com/${currentOrder.product.imageURL}`} className="max-h-full" />
              </div>
            </div>
            <div className="pt-2 px-0 md:px-10 pb-8 w-full md:w-1/2">
              <h1 className="
              sm:mt-0 mt-2 text-5xl font-light leading-large
              ">{currentOrder.product.title}</h1>
              <h2 className="text-2xl tracking-wide sm:py-8 py-6">{DENOMINATION}{currentOrder.product.price}</h2>
              <h4 className="text-gray-600 leading-7">
                {currentOrder.product.description}
              </h4>
              
              <Button 
                full
                title="Checkout"
                onClick={doRequest}
              />

            </div>
          </div>  
      </div>

     
    </div>
  )
}

export default Payment
