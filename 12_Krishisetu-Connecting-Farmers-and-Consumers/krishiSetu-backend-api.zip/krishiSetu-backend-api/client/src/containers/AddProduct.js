import React, {useEffect} from  'react';
import {useDispatch} from 'react-redux';
import { useForm } from "react-hook-form";
import Button from 'components/Button';
import {addProduct} from 'actions/products';
 
const AddProduct = () => {

  const { register, handleSubmit, formState: { errors }, reset, formState } = useForm();
  const dispatch = useDispatch();

  const onSubmit = (product) => {
    dispatch(addProduct(product));
  }

  useEffect(() => {
    if (formState.isSubmitSuccessful) {
      reset({ title: '', description: ''});
    }
  }, [reset]);


  return ( <div className="flex flex-col">
  <div className="max-w-fw flex flex-col">
  <div className="flex flex-1 justify-center">
  
    <div className="w-full max-w-144">
      <h2 className='text-4xl inline font-light'>
        Add Product
      </h2>
      <hr className='my-5'/>
      <form className="bg-white rounded px-8 pt-6 pb-8 mb-4" onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="title">
            Title
          </label>
          <input
            {...register("title", {required: "This field is required"})}
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"  type="text" placeholder="Title" />
          {errors.title && <p className="text-red-300">{errors.title.message}</p>}
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="description">
            Description
          </label>
          <textarea
            {...register("description", {required : "This field is required", minLength: {value: 30, message: "Discription must be greater than 30 characters"}})}
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" rows="4"placeholder="Discription" />
          {errors.description && <p className="text-red-300">{errors.description.message}</p>}
        </div>
        <div className="mb-6">
          <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="price">
            Price
          </label>
          <input
            {...register("price", {required : "This field is  required"})}
          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type='number' placeholder="Price in rupees" />
          {errors.price && <p className="text-red-300">{errors.price.message}</p>}
        </div>
        <div className="mb-6">
        <label className="block text-gray-700 text-sm font-bold mb-2" htmlFor="image">
            Choose an Image
          </label>
        <div className="flex items-center justify-between">
          <input
          {...register("image", {required: 'This field is required'})}
          className="bg-primary hover:bg-black text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full cursor-pointer" 
          type="file"
          accept="image/*"
          />
          {errors.image && <p className="text-red-300">{errors.image.message}</p>}
          </div> 
        </div>
        <div className='mt-6'>
          <Button 
            full
            title="Add Product"
          />  
            
          </div>
      </form>
    </div>
  </div>
  </div>
</div>
)
}

export default AddProduct;