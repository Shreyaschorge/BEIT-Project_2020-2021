import React, {useEffect} from 'react'
import {useSelector, useDispatch} from 'react-redux'
import Order from 'containers/Order';

import {fetchAllOrders} from 'actions/orders';

const MyOrders = () => {

  const {orders} = useSelector((state) => state.orders)

  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(fetchAllOrders());
  }, [dispatch]);

  console.log(orders);


  return (
    <div className="flex flex-col">
        <div className="max-w-fw flex flex-col">
          <div className="pt-10">
            <h1 className="text-5xl font-light">My Orders</h1>
          </div>
          <hr className='my-7'/>
          {orders.length === 0 ? (<h2 className='text-2xl font-light mb-7'>You haven't made any orders yet..</h2>): 
            orders.map((order) => {
              console.log(order);
              return <Order key={order.id} order={order}/>
            })
          }
        </div>
      </div>


  )
}

export default MyOrders
