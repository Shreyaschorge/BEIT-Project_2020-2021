import React from 'react'
import {useDispatch} from 'react-redux';
import Button from 'components/Button'

import { currentOrder } from 'actions/orders';

const Order = ({order}) => {

  console.log(order)
  
  const dispatch = useDispatch()

  return (
              <div className="border-b py-10 px-10">
                <div className="flex items-center">
                  
                    <a>
                      <img className="w-32 m-0" src={`https://krishisetu.s3.ap-south-1.amazonaws.com/${order.product.imageURL}`} />
                    </a>
                  
                 
                    <a>
                      <h2 className="m-0 pl-10 text-gray-600 text-sm text-xl">
                        {order.product.title}
                      </h2>
                    </a>
              
                  <div className="flex flex-1 justify-end">
                    {/* <h2 className="m-0 pl-10 text-gray-900 text-sm text-xl">Status: {order.status} </h2> */}
                    <h2 className="m-0 pl-20 text-gray-900 font-semibold font-size">
                      {order.product.price}
                    </h2>
                  </div>
                  
                  <div className='inline ml-20'>

                  <Button
                    full
                    title="Buy"
                    onClick={() => dispatch(currentOrder(order))}
                  />
                  </div>
                  

                </div>
              </div>
  )
}

export default Order
