import React, {useEffect} from 'react';
import {useDispatch} from 'react-redux';
import Products from 'containers/Products';

import { fetchAllProducts, fetchUserProducts } from 'actions/products';

const Home = () => {

  const dispatch = useDispatch()

  useEffect(() => {
    dispatch(fetchAllProducts());
    dispatch(fetchUserProducts());
  },[]);

  return (
    <div>
      <Products />
    </div>
  )
}

export default Home
