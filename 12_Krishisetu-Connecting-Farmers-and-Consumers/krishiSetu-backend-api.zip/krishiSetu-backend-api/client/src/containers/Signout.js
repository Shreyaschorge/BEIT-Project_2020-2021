import React, {useEffect} from 'react';
import {useDispatch} from 'react-redux';

import { signout } from 'actions/auth';

const Signout = () => {
  const dispatch = useDispatch()

  useEffect(()=>{
    dispatch(signout());
  }, [dispatch]);

  return (
    <div className = 'container justify-items-center my-auto'>
      <h2>Signing u out...</h2>
    </div>
  )
}

export default Signout
