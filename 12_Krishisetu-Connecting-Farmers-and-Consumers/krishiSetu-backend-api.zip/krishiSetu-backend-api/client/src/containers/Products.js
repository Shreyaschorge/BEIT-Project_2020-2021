import React from 'react';
import {useSelector} from 'react-redux';
import ProductItem from 'components/ProductItem';

const Products = () => {
    
    const {allProducts} = useSelector((state) => state.products)

    return (
        <>
        {allProducts.length === 0 ? 
        (<h2 className='text-4xl inline font-light mb-7'>
            There are no products available right now...
        </h2>) : 
        (<div className="flex flex-col items-center">
            <div className="max-w-fw flex flex-col w-full">
                <div className="pt-4 sm:pt-10 pb-8">
                <h1 className="text-5xl font-light">Recently Added</h1>
            </div>
            <div>
                <div className="flex flex-1 flex-wrap flex-row">
                {allProducts.map(({title, imageURL, price, description, userId, id}) => {
                    return (
                        <ProductItem key={imageURL} title={title} imageURL={imageURL} price={price} description={description} userId={userId} productId={id}/>
                    )
                })}
                </div>
            </div>
            </div>
        </div>)}

        </>
    )
}

export default Products;