import React, {useEffect} from 'react';
import {Link} from 'react-router-dom';
import {useSelector, useDispatch} from 'react-redux';
import Button from 'components/Button'
import history from '../history';
import ProductItem from 'components/ProductItem';

import {fetchUserProducts} from 'actions/products';

const SellProducts = () => {

  const {usersProducts} = useSelector((state) => state.products)
  const dispatch = useDispatch()

  const onSubmit = () => {
    history.push('add-product');
  }

  useEffect(() => {
    dispatch(fetchUserProducts())
  }, [dispatch])
  
  return (   
    <>
    <div className='p-5 flex justify-between'>
      <div>
      <h2 className='text-4xl inline font-light'>
          My Products
      </h2>
      </div>
      <Link to='add-product'>
        <Button title="Sell Product" onClick={onSubmit}/>
      </Link>
    </div>
    <hr className='mb-10'/>
    {usersProducts.length === 0 ? (<h2 className='text-3xl inline font-light'>
            Click on Sell Product to get started...
        </h2>): (
        <div className="flex flex-col items-center">
            <div className="max-w-fw flex flex-col w-full">
                
            <div>
                <div className="flex flex-1 flex-wrap flex-row">
                {usersProducts.map(({title, imageURL, price, description, userId, id}) => {
                    return (
                        <ProductItem key={imageURL} title={title} imageURL={imageURL} price={price} description={description} productId ={id} userId = {userId}/>
                    )
                })}
                </div>
            </div>
            </div>
        </div>)}
    </>
   )
}

export default SellProducts
