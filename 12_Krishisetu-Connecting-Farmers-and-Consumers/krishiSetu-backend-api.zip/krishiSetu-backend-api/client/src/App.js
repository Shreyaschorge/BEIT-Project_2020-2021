import React, {useEffect} from "react";
import {useSelector, useDispatch} from 'react-redux';
import {
  Switch,
  Route,
  Redirect,
  Router
} from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import history from "./history";

import NavBar from 'layout/NavBar';
import Home from 'containers/Home';
import Signup from 'containers/Signup';
import Signin from 'containers/Signin';
import Signout from 'containers/Signout';
import SellProducts from 'containers/SellProducts';
import MyOrders from 'containers/MyOrders';
import AddProduct from "containers/AddProduct";
import Product from "containers/Product";
import Payment from "containers/Payment";

import {getCurrentUser} from 'actions/auth';
import Footer from "layout/Footer";

function App() {

  const {errors} = useSelector((state) => state.errors)
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getCurrentUser());
  }, [dispatch]);

  useEffect(() => {
    if(errors){
      errors.forEach((error) => {
        toast.error(error.message, {
          position: "top-right",
          autoClose: 4000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          });
      })
    }
  },[errors]);

  return (
    <>
      <Router history={history}>
        {/* <BrowserRouter> */}
          <NavBar/>
          <Switch>
            <Redirect exact from='/' to='/home' />
            <Route exact path="/home" component={Home}/>
            <Route exact path="/signin" component={Signin} />
            <Route exact path="/add-product" component={AddProduct} />
            <Route exact path="/signup" component={Signup} />
            <Route exact path="/signout" component={Signout} />
            <Route exact path="/sell-products" component={SellProducts} />
            <Route exact path="/my-orders" component={MyOrders} />
            <Route exact path="/product" component={Product} />
            <Route exact path="/payment" component={Payment} />
          </Switch>
          <Footer />
        {/* </BrowserRouter> */}
        <ToastContainer autoClose={4000} />
      </Router>
    </>
  );
}

export default App;
