import { LOADING } from 'actions/constants';

const initialState = {
  loading : false,
};

const loading = (state = initialState, action) => {

  switch (action.type) {
    case LOADING:
      return {
        ...state,
        loading : !state.loading
      };

    default:
      return state;
  }
};

export default loading;