import {
  ALL_ORDERS, CURRENT_ORDER
} from "actions/constants";

const initialState = {
  orders : [],
  currentOrder: null
};

const orders = (state = initialState, action) => {
  switch (action.type) {
    case ALL_ORDERS:
      return {
        ...state,
        orders : action.payload
      };

    case CURRENT_ORDER:
      return {
        ...state,
        currentOrder : action.payload
      };

    default:
      return state;
  }
};

export default orders;
