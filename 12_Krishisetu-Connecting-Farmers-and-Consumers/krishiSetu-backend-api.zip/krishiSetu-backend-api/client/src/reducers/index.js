import {combineReducers} from 'redux';

import auth from 'reducers/authReducer';
import errors from './errorsReducer';
import products from 'reducers/productsReducer';
import orders from 'reducers/ordersReducer';

const appReducer = combineReducers({auth, errors, products, orders})

const rootReducer = (state, action) => {
  return appReducer(state, action);
};

export default rootReducer;