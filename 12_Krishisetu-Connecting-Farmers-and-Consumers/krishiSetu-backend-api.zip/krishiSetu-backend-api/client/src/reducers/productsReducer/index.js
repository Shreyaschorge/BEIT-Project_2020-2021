import { ALL_PRODUCTS, USERS_PRODUCTS, CURRENT_PRODUCT } from 'actions/constants';

const initialState = {
  allProducts : [],
  usersProducts : [],
  currentProduct : null
};

const products = (state = initialState, action) => {

  switch (action.type) {
    case ALL_PRODUCTS:
      return {
        ...state,
        allProducts : action.payload
      };
    case USERS_PRODUCTS:
      return {
        ...state,
        usersProducts : action.payload
      };
    case CURRENT_PRODUCT:
      return {
        ...state,
        currentProduct : action.payload
      };

    default:
      return state;
  }
};

export default products;