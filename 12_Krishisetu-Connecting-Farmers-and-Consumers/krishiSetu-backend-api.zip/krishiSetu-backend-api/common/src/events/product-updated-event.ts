import { Subjects } from './subjects';

export interface ProductUpdatedEvent {
  subject: Subjects.ProductUpdated;
  data: {
    id: string;
    version: number;
    title: string;
    price: number;
    description: string;
    imageURL: string;
    userId: string;
    orderId?: string;
  };
}