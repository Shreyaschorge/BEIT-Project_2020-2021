export const queueGroupName = 'products-service';
